/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in.model;

import com.in.bean.QuestionBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author a.seema
 */
public class QuestionModel {

    Connection con = null;

    public QuestionModel(Connection con) throws SQLException, ClassNotFoundException {
        this.con = con;
    }

    public List getCourses() {
       QuestionBean bean = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        List list = null;
        try {
            
            //con = ds.getConnection();
            pst = con.prepareStatement("select coursesId,course from courses");
            rs = pst.executeQuery();
            list = new ArrayList();
            while (rs.next()) {
                 bean = new QuestionBean();
                 Integer cid=rs.getInt(1);
                String cId=cid.toString();
                 bean.setcId(cId);
                bean.setCourse(rs.getString("course"));
                list.add(bean);
            }
            System.out.println("list size in dao "+list.size());
        } catch (Exception e) {
            System.out.println(e.getMessage());

        } finally {
            try {
                if (con != null) {
                    con.close();

                }
                if (pst != null) {
                    pst.close();
                }
            } catch (Exception e1) {
                con = null;
            }

        }
        return list;
    }

}
