/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.in.model;

import com.in.bean.UserBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author a.seema
 */
public class UserModel {

Connection con=null;
    public UserModel(Connection con) {
        this.con = con;
    }

    public String register(UserBean bean) {
       // Connection con = null;
        PreparedStatement pst = null;
        String redirect = null;
        try {
          //  con = ds.getConnection();
            pst = con.prepareStatement("select userEmail from user where UserEmail=?");
            pst.setString(1, bean.getEmail());
            ResultSet rs = pst.executeQuery();
            if (!rs.next()) {
                pst = con.prepareStatement("insert into user(userName, userEmail, mobileNo, password, roleId) values(?,?,?,?,?)");
                pst.setString(1, bean.getUname());
                pst.setString(2, bean.getEmail());
                pst.setString(3, bean.getNo());
                pst.setString(4, bean.getPwd());
                pst.setInt(5, 2);
                Integer i = pst.executeUpdate();
                if (i != null) {
                    redirect = "success";
                }
            } else {
                redirect = "fail";
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return redirect;
    }

    public UserBean get(String email) {
       // Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        UserBean bean = null;
        try {
           // con = ds.getConnection();
            pst = con.prepareStatement("select userName,password from user where userEmail=?");
            pst.setString(1, email);
            rs = pst.executeQuery();
            if (rs.next()) {
                bean = new UserBean();
                bean.setUname(rs.getString("userName"));
                bean.setPwd(rs.getString("password"));
            }

        } catch (Exception e) {
            System.out.println("Exc " + e.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();

                }
                if (pst != null) {
                    pst.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e1) {
                con = null;
            }
        }

        return bean;
    }

    public String retreive(String email) {
       // Connection con = null;
        PreparedStatement ps = null;
        UserBean mb = null;
        ResultSet rs = null;
        String status = null;
        try {
            //con = ds.getConnection();
            System.out.println("con "+con);
            ps = con.prepareStatement("select userEmail from user where userEmail=? ");
            ps.setString(1, email);

            rs = ps.executeQuery();
            System.out.println("rset" + rs);

            if (rs.next()) {

                status = "success";
            } else {

                status = "fail";
            }
        } catch (Exception e) {
            System.out.println("Exception" + e.getMessage());
        } finally {
           
        }
        return status;
    }

    public UserBean retreive(String email, String pwd) {
        //Connection con = null;
        PreparedStatement ps = null;
        UserBean mb = null;
        ResultSet rs = null;
        Boolean status = null;
        try {
            //con = ds.getConnection();
            ps = con.prepareStatement("select s.userName,s.roleId,s.userId,r.roleName from user s, role r where s.roleId=r.roleId and userEmail=? and password=?");
            ps.setString(1, email);
            ps.setString(2, pwd);
            rs = ps.executeQuery();

            if (rs.next()) {
                mb = new UserBean();
                System.out.println("In if block");
                mb.setRoleId(rs.getInt("roleId"));
                mb.setRoleName(rs.getString("roleName"));
                mb.setUserId(rs.getInt("userId"));
                mb.setUname(rs.getString("userName"));
                System.out.println("user name" + rs.getString("userName"));
                status = true;

            } else {
                System.out.println("In else block");
                status = false;
                System.out.println("In else block" + status);
                return mb;
            }
        } catch (Exception e) {
            System.out.println("Exception" + e.getMessage());
        } finally {
            
        }
        return mb;
    }

    public String insertComment(String uName, String uEmail, String comment) {
       // Connection con = null;
        PreparedStatement pst = null;
        String redirect = null;
        ResultSet rs=null;
        try {
           // con = ds.getConnection();
            pst = con.prepareStatement("select userEmail from user where userEmail=?");
            pst.setString(1, uEmail);
             rs = pst.executeQuery();
            if (rs.next()) {
                pst = con.prepareStatement("update user set comments=? where userEmail=? ");
                pst.setString(1, comment);
                pst.setString(2, uEmail);
                Integer i = pst.executeUpdate();
                if (i != null) {
                    redirect = "success";
                }
            } else {
                redirect = "fail";
            }
        } catch (Exception e) {
            e.printStackTrace();

        }finally {
            try {
                if (con != null) {
                    con.close();

                }
                if (pst != null) {
                    pst.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e1) {
                con = null;
            }
        }
        return redirect;
    }

    public List getComments() {
       // Connection con = null;
        PreparedStatement ps = null;
        UserBean mb = null;
        ResultSet rs = null;
        String status = null;
        List list=new ArrayList();
        try {
           // con = ds.getConnection();
            ps = con.prepareStatement("select comments from user");
            rs = ps.executeQuery();
            System.out.println("rs   "+rs);
            while(rs.next()) {
                mb=new UserBean();
                if(rs.getString("comments")!=null){
                mb.setComment(rs.getString("comments"));
                System.out.println("comments "+mb.getComment());
                list.add(mb);
                }
            } 
        } catch (Exception e) {
            System.out.println("Exception" + e.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();

                }
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e1) {
                con = null;
            }
        }
        return list;
    }
    public List getCourse() {
      //  Connection con = null;
        PreparedStatement ps = null;
        UserBean mb = null;
        ResultSet rs = null;
        String status = null;
        List list=new ArrayList();
        try {
           // con = ds.getConnection();
            ps = con.prepareStatement("select * from courses");
            rs = ps.executeQuery();
            while(rs.next()) {
                mb=new UserBean();
                mb.setCourseId(rs.getString("coursesId"));
                mb.setCourses(rs.getString("course"));
                list.add(mb);
            }
        } catch (Exception e) {
            System.out.println("Exception" + e.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();

                }
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }

            } catch (Exception e1) {
                con = null;
            }
        }
        return list;
    }
}
