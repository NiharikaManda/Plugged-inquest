/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.in.exception;

/**
 *
 * @author kalpana
 */
public class DatabaseTypeException extends Exception{
    private String message = null;

    public DatabaseTypeException(){
        this("Database type provided is invalid");
    }

    public DatabaseTypeException(String message){
        super(message);
    }

    public String toString(){
        return message;
    }

}
