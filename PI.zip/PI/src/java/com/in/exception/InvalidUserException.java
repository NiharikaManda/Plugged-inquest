/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.in.exception;

/**
 *
 * @author kalpana
 */
public class InvalidUserException  extends Exception{
 private String message = null;

    public InvalidUserException(String message) {
        super(message);
        this.message = message;
    }

    public InvalidUserException() {
        this("Invalid user details");
    }

    @Override
    public String toString(){
        return message;
    }
}
