/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.in.bean;

import java.util.ArrayList;

/**
 *
 * @author a.seema
 */
public class QuestionBean {
    private Integer qId;
    private String questions;
    private String answer;
    private String cId;
    private String answer1;
    private String answer2;
    private String course;

    public String getCourse() {
        return course;
    }
    public void setCourse(String course) {
        this.course = course;
    }
    public String getAnswer1() {
        return answer1;
    }

    public void setAnswer1(String answer1) {
        this.answer1 = answer1;
    }

    public String getAnswer2() {
        return answer2;
    }

    public void setAnswer2(String answer2) {
        this.answer2 = answer2;
    }

    public String getcId() {
        return cId;
    }
    public void setcId(String cId) {
        this.cId = cId;
    }
    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Integer getqId() {
        return qId;
    }

    public void setqId(Integer qId) {
        this.qId = qId;
    }

    public String getQuestions() {
        return questions;
    }

    public void setQuestions(String questions) {
        this.questions = questions;
    }
public QuestionBean(String answer) {
        this.answer = answer;
    }
public QuestionBean(){
    
}

    public ArrayList loadList() {
        ArrayList userList = new ArrayList();
        QuestionBean bean = new QuestionBean(getAnswer1());
        QuestionBean bean1 = new QuestionBean(getAnswer2());
        userList.add(bean);
        userList.add(bean1);
        return userList;
    }
   

}
