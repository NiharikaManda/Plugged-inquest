/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kalpana
 */
public class GetScore extends HttpServlet {
            private static Integer counter = 0;
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        String redirect = null;
        if (userId != null) {
            ArrayList arraylist=new ArrayList();
            String course=(String)session.getAttribute("getcourse");
            System.out.println("course _________________________"+course);
            List answersList = getAnswerList(course);
            System.out.println("answerList     size " + answersList.size());
            
            for (int i = 1; i <= answersList.size(); i++) {
                System.out.println("---"+request.getParameter("answer"+i));
                String answers=request.getParameter("answer"+i);
                arraylist.add(answers);
            }
            
            System.out.println("small   " + getAnswerList(course).size());
            System.out.println("size arraylist "+arraylist.size());
            for (int i = 0; i < answersList.size(); i++) {
                //System.out.println("bean_________" + (getAnswers(arraylist).get(i)).equals((getAnswerList(course).get(i))));
                if ((getAnswers(arraylist).get(i)).equals((getAnswerList(course).get(i)))) {
                    counter++;
                    System.out.println("counter" + counter);
                }
            }
            request.setAttribute("count", counter);
            int nullcount=sendNullCount(arraylist);
            Integer c=(Integer)session.getAttribute("noOfQuestions");
            int ca=c-nullcount;
            System.out.println("nullc------"+ca);
            request.setAttribute("nullcount", ca);
          //  System.out.println("counter" + counter);
            counter = 0;
           // System.out.println("counter" + counter);

            redirect = "score.jsp";

        } else {
            redirect = "login.jsp";
            request.setAttribute("false", "Please Login ");
        }
      RequestDispatcher rd=request.getRequestDispatcher(redirect);
      rd.forward(request, response);
       
    }
    public List getAnswers(ArrayList al) {
       
        List answerlist = new ArrayList();
         for (int i = 0; i < al.size(); i++) {           
        answerlist.add((al.get(i) != null) ? al.get(i) : " ");          
         }        
          return answerlist;
    }
    
    public int sendNullCount(ArrayList al){
        int nullCount=0;
        for (int i = 0; i < al.size(); i++) {
            String answer =(String)al.get(i); 
            if(answer==null){
             System.out.println("answer in method "+answer);
              nullCount++;
            }
        }
         System.out.println("nullcount "+nullCount);
        return nullCount;
    }
    String strLine = null;

    public List getAnswerList(String course) {
        List list = new ArrayList();
        try {

          String file = course + "Answers.txt";
            FileInputStream fstream = new FileInputStream(
                    getServletContext().getRealPath(file));
            System.out.println("path___"+getServletContext().getRealPath("answers.txt"));
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            while ((strLine = br.readLine()) != null) {
                list.add(strLine);

            }
            in.close();
        } catch (Exception e) {//Catch exception if any
            e.printStackTrace();
            System.err.println("Error: " + e.getMessage());
        }
        return list;
    }
    


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
