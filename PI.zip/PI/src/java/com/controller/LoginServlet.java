/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.in.bean.UserBean;
import com.in.model.UserModel;
import com.in.util.DBUtil;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kalpana
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection con=DBUtil.getConnection();
        String redirect = null;
        HttpSession session = request.getSession(true);
        String email=request.getParameter("email");
        String pwd=request.getParameter("password");
        System.out.println("email" + email);
        System.out.println("pwd" + pwd);
        try {
            UserModel lm1 = new UserModel(con);
            String valide = lm1.retreive(email);
            System.out.println("valide " + valide);
            if (valide.equals("success")) {
                 UserModel lm = new UserModel(con);
                UserBean bean = lm.retreive(email, pwd);
                System.out.println("memberbean  " + bean);
                if (bean != null) {
                     UserModel lm2 = new UserModel(con);
                    String roleName = bean.getRoleName();
                    System.out.println("roleName " + roleName);
                    List cList=lm2.getCourse();
                    System.out.println("list size "+cList.size());
                    if ("user".equals(roleName)) {
                        session.setAttribute("course", cList);
                        session.setAttribute("roleId", bean.getRoleId());
                        session.setAttribute("userId", bean.getUserId());
                        session.setAttribute("uName", bean.getUname());
                        redirect = "test1.jsp";
                    } else {
                        session.setAttribute("userId", bean.getUserId());
                        session.setAttribute("UName", bean.getUname());
                        session.setAttribute("roleId", bean.getRoleId());
                        redirect = "home.jsp";
                    }
                } else {
                    request.setAttribute("error", "Login credentials mismatch");
                    redirect = "login.jsp";
                }
            } else {
                request.setAttribute("error", "Doesn't Exist Please Register");
                redirect = "login.jsp";
            }
           RequestDispatcher rd=request.getRequestDispatcher(redirect);
           rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("This is exception in Login servlet: " + e.getMessage());
            //e.printStackTrace();
        } finally {
             try {
                if (con != null) {
                    con.close();

                }
               

            } catch (Exception e1) {
                con = null;
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
