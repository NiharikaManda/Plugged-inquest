/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kalpana
 */
public class AddingQuestions extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        String redirect=null;
        if (userId != null) {
            System.out.println("answer___________ " + request.getParameter("answer"));           
            String course = request.getParameter("course");
            Boolean flag = addQuestion(request.getParameter("question").trim(), course);
            Boolean flag2 = addOptions(request.getParameter("option1").trim(), request.getParameter("option2").trim(), request.getParameter("option3").trim(), course);
            Boolean flag3 = addAnswer(request.getParameter("answer").trim(), course);
            request.setAttribute("success", "submitted successfully");
            System.out.println("flag " + flag);
           userId=null;
           redirect="addquestion.jsp";
        }else{
           redirect="login.jsp";
           request.setAttribute("false", "Please Login ");
        }
        RequestDispatcher rd=request.getRequestDispatcher(redirect);
        rd.forward(request, response);
    } 

    

    public Boolean addQuestion(String question, String course) {
        Boolean flag = false;
        FileOutputStream out;        
        try {
            String file = course + "Questions.txt";

            FileOutputStream f = new FileOutputStream(getServletContext().getRealPath(file), true);
            System.out.println("path " + getServletContext().getRealPath(file));
            // FileOutputStream f = new FileOutputStream("questions.txt", true);
            char[] buf = new char[question.length()];
            question.getChars(0, question.length(), buf, 0);
            Integer i = 0;
            for (i = 0; i < buf.length; i++) {
                f.write(buf[i]);
            }
            f.write('\n');

            // f.flush();
            System.out.println("question" + question);
            flag = true;
            System.out.println("The Text is written ");

            f.close();
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }

        return flag;
    }

    public Boolean addOptions(String op1, String op2, String op3, String course) {
        Boolean flag = false;
        FileOutputStream out;       
        try {
            String file = course + "Options.txt";
            System.out.println("path " + getServletContext().getRealPath(file));
            FileOutputStream f = new FileOutputStream(getServletContext().getRealPath(file), true);
            // FileOutputStream f = new FileOutputStream("questions.txt", true);
            String options = op1 + "  " + op2 + "  " + "  " + op3;
            char[] buf = new char[options.length()];
            options.getChars(0, options.length(), buf, 0);
            Integer i = 0;
            for (i = 0; i < buf.length; i++) {
                f.write(buf[i]);
            }
            f.write('\n');
            // f.flush();
            System.out.println("question" + options);
            flag = true;
            System.out.println("The Text is written ");

            f.close();
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }

        return flag;
    }

    public Boolean addAnswer(String answer, String course) {
        Boolean flag = false;
        FileOutputStream out;
        try {
            String file = course + "Answers.txt";
            System.out.println("path " + getServletContext().getRealPath(file));
            FileOutputStream f = new FileOutputStream(getServletContext().getRealPath(file), true);
            // FileOutputStream f = new FileOutputStream("questions.txt", true);
            char[] buf = new char[answer.length()];
            answer.getChars(0, answer.length(), buf, 0);
            Integer i = 0;
            for (i = 0; i < buf.length; i++) {
                f.write(buf[i]);
            }
            f.write('\n');

            // f.flush();
            System.out.println("question" + answer);
            flag = true;
            System.out.println("The Text is written ");

            f.close();
        } catch (Exception e) {
            System.err.println("Error writing to file");
        }

        return flag;
    }


    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
